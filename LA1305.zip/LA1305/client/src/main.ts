const frenchmode: HTMLButtonElement | null = document.createElement('button')
const englishmode: HTMLButtonElement | null = document.createElement('button')
let answeranzeige = document.getElementById('answeranzeig')

let app: HTMLDivElement = document.querySelector('#app')!

console.log(app.innerHTML)

englishmode.textContent = 'english'
frenchmode.textContent = 'french'

const auswahl: HTMLElement | null = document.querySelector('#auswahl')
const main: HTMLDivElement | null = document.querySelector('#main')
if (auswahl) {
  auswahl.append(frenchmode)
  auswahl.append(englishmode)
}

app.textContent = '©2023'

frenchmode?.addEventListener('click', () => {
  console.log('Button clicked!')
  fetch('http://localhost:3000/vocis/')
    .then((response) => response.json())
    .then((data) => {
      const scoreDisplay: HTMLParagraphElement | null =
        document.querySelector('#answerzeige')

      if (main && scoreDisplay) {
        let currentQuestionIndex = 0
        let correctAnswers = 0

        const displayQuestion = () => {
          const item = data[currentQuestionIndex]
          const paragraph: HTMLParagraphElement = document.createElement('p')
          paragraph.textContent = item.german

          const input: HTMLInputElement = document.createElement('input')
          input.setAttribute('type', 'text')
          input.setAttribute('placeholder', 'Enter value for French')

          input.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
              const userAnswer = input.value.trim().toLowerCase()
              if (userAnswer === item.french.toLowerCase()) {
                answeranzeige!.innerHTML = 'You got the correct answer'
                correctAnswers++
              } else {
                console.log('Incorrect translation!')
                answeranzeige!.innerHTML =
                  'The correct translation is: ' + item.french
              }

              currentQuestionIndex++
              if (currentQuestionIndex < data.length) {
                paragraph.remove()
                input.remove()
                displayQuestion()
              } else {
                showFinalScore()
              }
            }
          })
          main.appendChild(paragraph)
          main.appendChild(input)
        }
        const showFinalScore = () => {
          console.log('first')

          main.innerHTML = 'Final Score: ' + correctAnswers + '/' + data.length
        }
        displayQuestion()
      }
    })
    .catch((error) => {
      console.error('Error fetching data:', error)
    })
})

englishmode?.addEventListener('click', () => {
  console.log('Button clicked!')
  fetch('http://localhost:3000/vocis/')
    .then((response) => response.json())
    .then((data) => {
      const scoreDisplay: HTMLParagraphElement | null =
        document.querySelector('#score')

      if (main && scoreDisplay) {
        let currentQuestionIndex = 0
        let correctAnswers = 0

        const displayQuestion = () => {
          const item = data[currentQuestionIndex]
          const paragraph: HTMLParagraphElement = document.createElement('p')
          paragraph.textContent = item.german

          const input: HTMLInputElement = document.createElement('input')
          input.setAttribute('type', 'text')
          input.setAttribute('placeholder', 'Enter value for English')

          input.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
              const userAnswer = input.value.trim().toLowerCase()
              if (userAnswer === item.english.toLowerCase()) {
                answeranzeige!.innerHTML = 'You got the correct answer'
                correctAnswers++
              } else {
                console.log('Incorrect translation!')
                answeranzeige!.innerHTML =
                  'The correct translation is: ' + item.english
              }

              currentQuestionIndex++
              if (currentQuestionIndex < data.length) {
                paragraph.remove()
                input.remove()
                displayQuestion()
              } else {
                showFinalScore()
              }
            }
          })
          main.appendChild(paragraph)
          main.appendChild(input)
        }

        const showFinalScore = () => {
          console.log('first')

          main.innerHTML = 'Final Score: ' + correctAnswers + '/' + data.length
        }

        displayQuestion()
      }
    })
    .catch((error) => {
      console.error('Error fetching data:', error)
    })
})
